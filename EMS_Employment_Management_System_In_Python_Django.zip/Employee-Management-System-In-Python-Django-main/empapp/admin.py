
from django.contrib import admin
from .models import leave
# Register your models here.
admin.site.register(leave)